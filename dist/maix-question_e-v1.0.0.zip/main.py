import struct
from maix import image, display, app, time, camera, touchscreen
from maix import comm, protocol
import cv2
import numpy as np

class PIDController:
    def __init__(self, kp, ki, kd, output_limit):
        self.kp = kp
        self.ki = ki
        self.kd = kd
        self.output_limit = output_limit
        self.prev_error = 0.0
        self.integral = 0.0
    def update(self, error, dt):
        self.integral += error * dt
        self.integral = max(-100, min(100, self.integral))
        derivative = (error - self.prev_error) / dt if dt > 0 else 0.0
        output = self.kp * error + self.ki * self.integral + self.kd * derivative
        output = max(-self.output_limit, min(self.output_limit, output))
        self.prev_error = error
        return float(output)
    def reset(self):
        self.prev_error = 0.0
        self.integral = 0.0

class HSVController:
    def __init__(self, initial_lower, initial_upper):
        self.lower_hsv = list(initial_lower)  # [H_min, S_min, V_min]
        self.upper_hsv = list(initial_upper)  # [H_max, S_max, V_max]
        self.current_mode = "select"  # "select", "h", "s", "v"
        self.step_size = [5, 10, 10]  # H, S, V 的调节步长
        
    def get_hsv_range(self):
        return np.array(self.lower_hsv), np.array(self.upper_hsv)

class TouchInterface:
    def __init__(self, disp_width, disp_height):
        self.ts = touchscreen.TouchScreen()
        self.disp_width = disp_width
        self.disp_height = disp_height
        self.pressed_already = False
        self.last_x = 0
        self.last_y = 0
        self.last_pressed = False
        
    def create_button(self, x, y, width, height, text, color=(255, 255, 255)):
        return {
            'x': x, 'y': y, 'width': width, 'height': height,
            'text': text, 'color': color
        }
    
    def draw_button(self, frame, button, is_selected=False):
        color = (0, 255, 0) if is_selected else button['color']
        # 绘制按钮边框
        cv2.rectangle(frame, 
                     (button['x'], button['y']), 
                     (button['x'] + button['width'], button['y'] + button['height']), 
                     color, 2)
        # 绘制按钮文本
        text_size = cv2.getTextSize(button['text'], cv2.FONT_HERSHEY_SIMPLEX, 0.4, 1)[0]
        text_x = button['x'] + (button['width'] - text_size[0]) // 2
        text_y = button['y'] + (button['height'] + text_size[1]) // 2
        cv2.putText(frame, button['text'], (text_x, text_y), 
                   cv2.FONT_HERSHEY_SIMPLEX, 0.4, color, 1)
    
    def is_button_pressed(self, x, y, button):
        return (button['x'] <= x <= button['x'] + button['width'] and 
                button['y'] <= y <= button['y'] + button['height'])
    
    def check_touch(self, disp):
        x_raw, y_raw, pressed = self.ts.read()
        clicked = False
        
        # 坐标映射：将触摸屏坐标映射到显示图像坐标
        # 参考示例代码的坐标映射方法
        x, y = image.resize_map_pos_reverse(
            self.disp_width, self.disp_height,  # 图像尺寸
            disp.width(), disp.height(),        # 显示屏尺寸
            image.Fit.FIT_CONTAIN,              # 适配模式
            x_raw, y_raw                        # 原始触摸坐标
        )
        
        # 检测到触摸释放时认为是点击
        if pressed:
            self.pressed_already = True
        else:
            if self.pressed_already:
                clicked = True
                self.pressed_already = False
        
        # 返回映射后的坐标、按下状态和是否为点击事件
        return x, y, pressed, clicked, x_raw, y_raw

def find_laser():
    # 初始化
    disp = display.Display()
    cam = camera.Camera(360, 270, image.Format.FMT_BGR888)
    
    # 初始化通信协议 (自动根据系统配置初始化UART或TCP)
    p = comm.CommProtocol(buff_size=1024)
    
    # 画面中心和死区
    # CENTER_X, CENTER_Y = 160, 120 # 这些在计算error时已经不再需要，直接依赖 rect_center
    DEAD_ZONE = 3
    
    # PID控制器 (位置式)
    pid_x = PIDController(kp=0.2, ki=0.02, kd=0.02, output_limit=4.0)
    pid_y = PIDController(kp=0.2, ki=0.02, kd=0.02, output_limit=4.0)
    current_gimbal_angle_x = 0.0
    current_gimbal_angle_y = 0.0
    
    # 识别405nm蓝紫色激光的HSV范围（可根据实际调整）
    # 调整V值以包含更亮的中心区域，并适当放宽S值
    blueviolet_lower = np.array([120, 30, 80])  # H约120~140，S/V适当放宽
    blueviolet_upper = np.array([140, 255, 255])
    
    # 初始化触摸界面
    touch_ui = TouchInterface(360, 270) # 注意：触摸界面代码未在此次修改中激活，请根据需要自行集成。
    
    # 时间记录
    last_time = time.ticks_ms()
    
    # 用于形态学操作的核
    kernel_morph = np.ones((5, 5), np.uint8) # 闭运算和开运算的核，可以根据光斑大小调整

    # 创建界面按钮 (目前未在主循环中使用，仅是定义)
    h_btn = touch_ui.create_button(10, 200, 30, 25, "H")
    s_btn = touch_ui.create_button(50, 200, 30, 25, "S") 
    v_btn = touch_ui.create_button(90, 200, 30, 25, "V")
    min_minus_btn = touch_ui.create_button(10, 180, 35, 20, "Min-")
    min_plus_btn = touch_ui.create_button(50, 180, 35, 20, "Min+")
    max_minus_btn = touch_ui.create_button(90, 180, 35, 20, "Max-")
    max_plus_btn = touch_ui.create_button(130, 180, 35, 20, "Max+")
    exit_btn = touch_ui.create_button(170, 180, 35, 20, "Exit")
    
    # 初始化 FrameDetector
    frame_detector = FrameDetector(
        min_area=1000,
        max_area=cam.width() * cam.height() * 0.8,
        min_aspect_ratio=0.5,
        max_aspect_ratio=2.0,
        black_lower=np.array([0, 0, 0]),
        black_upper=np.array([180, 255, 60])
    )
    
    while not app.need_exit():
        # 计算时间间隔
        current_time = time.ticks_ms()
        dt = (current_time - last_time) / 1000.0  # 转换为秒
        last_time = current_time
        
        img = cam.read()
        frame = image.image2cv(img, ensure_bgr=False, copy=False)
        hsv = cv2.cvtColor(frame, cv2.COLOR_BGR2HSV)
        
        # --- 激光点识别 ---
        mask_laser = cv2.inRange(hsv, blueviolet_lower, blueviolet_upper)
        
        # 形态学闭运算：填充内部空洞
        mask_laser = cv2.morphologyEx(mask_laser, cv2.MORPH_CLOSE, kernel_morph)
        # 形态学开运算：消除小的噪声点
        mask_laser = cv2.morphologyEx(mask_laser, cv2.MORPH_OPEN, kernel_morph)

        # 轮廓识别激光点并计算质心
        contours_laser, _ = cv2.findContours(mask_laser, cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_SIMPLE)
        laser_center = None
        if contours_laser:
            largest_contour = max(contours_laser, key=cv2.contourArea)
            
            # 过滤掉过小或过大的轮廓，确保是激光点
            area = cv2.contourArea(largest_contour)
            if 10 < area < 50: # 根据实际激光点大小和分辨率调整面积限制
                # 计算图像矩
                M = cv2.moments(largest_contour)
                
                # 避免除以零，如果 M["m00"] 为 0，说明轮廓面积为 0
                if M["m00"] != 0:
                    cX = int(M["m10"] / M["m00"])
                    cY = int(M["m01"] / M["m00"])
                    laser_center = (cX, cY)
                    
                    # 可视化激光点中心
                    cv2.circle(frame, laser_center, 5, (0, 0, 255), -1) # 红色圆点表示质心
                    # 可视化激光点轮廓
                    cv2.drawContours(frame, [largest_contour], -1, (255, 0, 255), 2) # 粉色轮廓
                    cv2.putText(frame, f"Laser: {laser_center}", (laser_center[0]+10, laser_center[1]-10), cv2.FONT_HERSHEY_SIMPLEX, 0.4, (255,0,255), 1)
        
        # --- 只识别矩形中心，激光点固定在屏幕中心 ---
        center_x, center_y = 360 // 2, 270 // 2  # 屏幕中心
        rect_center = None
        frames, mask_black = frame_detector.detect_frames(frame)
        if frames:
            outer = next((f for f in frames if f['type']=='outer'), None)
            target = outer if outer else max(frames, key=lambda f: f['area'])
            rect_center = target['center']
            cv2.drawContours(frame, [target['approx']], -1, (0,255,0), 2)  # 边框线宽2
            cv2.circle(frame, rect_center, 7, (0,255,0), 2)  # 中点线宽2
            cv2.putText(frame, f"Rect Center: {rect_center}", (rect_center[0]-40, rect_center[1]-10), cv2.FONT_HERSHEY_SIMPLEX, 0.4, (0,255,0), 1)
        if rect_center:
            error_x = center_x - rect_center[0]
            error_y = center_y - rect_center[1]
            output_x = pid_x.update(error_x, dt)
            output_y = -pid_y.update(error_y, dt)
            print(f"Screen Center: ({center_x}, {center_y}) | Rect Center: {rect_center} | Error: ({error_x}, {error_y}) | PID: ({output_x:.3f}, {output_y:.3f})")
            cv2.putText(frame, f"Error Center->Rect: ({error_x}, {error_y})", (10, 15), cv2.FONT_HERSHEY_SIMPLEX, 0.4, (255,255,255), 1)
            cv2.putText(frame, f"Rect Center: ({rect_center[0]}, {rect_center[1]})", (10, 30), cv2.FONT_HERSHEY_SIMPLEX, 0.4, (0,255,0), 1)
            if abs(error_x) > DEAD_ZONE or abs(error_y) > DEAD_ZONE:
                data = struct.pack("<dd", float(output_x), float(output_y))
                p.report(0x11, data)
                cv2.putText(frame, f"Gimbal: ({output_x:.2f}, {output_y:.2f})", (10, 45), cv2.FONT_HERSHEY_SIMPLEX, 0.4, (0,255,255), 1)
            else:
                cv2.putText(frame, "Screen center aligned with Rect Center", (10, 45), cv2.FONT_HERSHEY_SIMPLEX, 0.4, (0,255,0), 1)
        else:
            pid_x.reset()
            pid_y.reset()
            cv2.putText(frame, "No rectangle detected", (10, 15), cv2.FONT_HERSHEY_SIMPLEX, 0.4, (0,0,255), 1)
        # 屏幕中心画激光点（红色圆点）和十字线，十字线宽3
        cv2.circle(frame, (center_x, center_y), 5, (0, 0, 255), 1)
        cv2.line(frame, (center_x - 15, center_y), (center_x + 15, center_y), (0, 255, 0), 3)
        cv2.line(frame, (center_x, center_y - 15), (center_x, center_y + 15), (0, 255, 0), 3)
        img_show = image.cv2image(frame, bgr=True, copy=False)
        disp.show(img_show, fit=image.Fit.FIT_CONTAIN)
        time.sleep_ms(50)

class FrameDetector:
    def __init__(self, min_area, max_area, min_aspect_ratio, max_aspect_ratio, black_lower, black_upper):
        self.min_area = min_area
        self.max_area = max_area
        self.min_aspect_ratio = min_aspect_ratio
        self.max_aspect_ratio = max_aspect_ratio
        self.black_lower = black_lower
        self.black_upper = black_upper

    def detect_frames(self, frame):
        """检测黑色方框，返回内外框信息"""
        hsv = cv2.cvtColor(frame, cv2.COLOR_BGR2HSV)
        mask_black = cv2.inRange(hsv, self.black_lower, self.black_upper)
        kernel = np.ones((3, 3), np.uint8)
        mask_black = cv2.morphologyEx(mask_black, cv2.MORPH_CLOSE, kernel)
        mask_black = cv2.morphologyEx(mask_black, cv2.MORPH_OPEN, kernel)
        contours, hierarchy = cv2.findContours(mask_black, cv2.RETR_TREE, cv2.CHAIN_APPROX_SIMPLE)
        frames = []
        if contours and hierarchy is not None:
            for i, contour in enumerate(contours):
                area = cv2.contourArea(contour)
                if area < self.min_area or area > self.max_area:
                    continue
                x, y, w, h = cv2.boundingRect(contour)
                aspect_ratio = float(w) / h
                if aspect_ratio < self.min_aspect_ratio or aspect_ratio > self.max_aspect_ratio:
                    continue
                epsilon = 0.02 * cv2.arcLength(contour, True)
                approx = cv2.approxPolyDP(contour, epsilon, True)
                if len(approx) >= 4:
                    M = cv2.moments(contour)
                    if M["m00"] != 0:
                        center_x = int(M["m10"] / M["m00"])
                        center_y = int(M["m01"] / M["m00"])
                    else:
                        center_x = x + w // 2
                        center_y = y + h // 2
                    frame_info = {
                        'contour': contour,
                        'approx': approx,
                        'center': (center_x, center_y),
                        'bbox': (x, y, w, h),
                        'area': area,
                        'type': 'unknown',
                        'aspect_ratio': aspect_ratio
                    }
                    frames.append(frame_info)
        if len(frames) == 2:
            frames.sort(key=lambda f: f['area'])
            inner_frame = frames[0]
            outer_frame = frames[1]
            inner_frame['type'] = 'inner'
            outer_frame['type'] = 'outer'
            return [outer_frame, inner_frame], mask_black
        return frames, mask_black

if __name__ == "__main__":
    find_laser()

